package com.example.ajudacap;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class cadastro extends AppCompatActivity {
    SQLiteDatabase database;

    String strID = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cadastro);
        abrirBanco();
        EditText txtNome= findViewById(R.id.txtNome);
        EditText txtSobreN= findViewById(R.id.txtSobrenome);
        EditText txtEmail= findViewById(R.id.txtEmail);
        EditText txtCPF= findViewById(R.id.txtCPF);
        EditText txtSenha= findViewById(R.id.txtSenha);
        Button btnCadastrar= findViewById(R.id.BtnCadastrar);
        Spinner SpinnerBairro = findViewById(R.id.spinnerBairro);
        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            String Nome= txtNome.getText().toString();
            String Sobrenome= txtSobreN.getText().toString();
            String Email= txtEmail.getText().toString();
            String CPF=txtCPF.getText().toString();
            String Senha=txtSenha.getText().toString();
                if(Nome.equals("") || Sobrenome.equals("") || Email.equals("") || CPF.equals("") || Senha.equals("")){


            }else{
                    //insere um disciplina
                    database.execSQL("INSERT INTO users (Fname,Lname ,email,password,CPF,bairro_id ) " +
                            "VALUES ('"+ Nome +"', " +
                            "'" + Sobrenome + "'," +
                            " '" + Email + "'" +
                            " '" + Senha + "'" +
                            " '" + CPF + "'" +
                            " '" + 1 + "'" +")");
                    Toast.makeText(cadastro.this,
                            "Usuario cadastrado com sucesso!",
                            Toast.LENGTH_SHORT).show();
                    Intent i = new Intent();


                }
            }
        });




    }

    private void abrirBanco() {
        database = openOrCreateDatabase(
                "sqlite",
                MODE_PRIVATE,
                null
        );
    }
    private void verificaBanco(){
        try {
            database=openOrCreateDatabase("chatapp",MODE_PRIVATE,null);
            database.execSQL("CREATE TABLE `users`"+"("
                    + " 'user_id' int(11) NOT NULL,"+
                    "`unique_id` int(255) NOT NULL,"+
                    "`fname` varchar(255) NOT NULL,"+
                    "`lname` varchar(255) NOT NULL,"+
                    "`email` varchar(255) NOT NULL,"+
                    " `password` varchar(255) NOT NULL,"+
                    "`CPF` varchar(255) NOT NULL,"+
                    "`bairro_id` int NOT NULL,"+
                    "FOREIGN KEY (bairro_id) references bairro(user_id));"+
                    "ALTER TABLE `users` ADD PRIMARY KEY (`user_id`);"+
                    "CREATE TABLE `messages` (" +
                    "  `msg_id` int(11) NOT NULL," +
                    "  `incoming_msg_id` int(255) NOT NULL," +
                    "  `outgoing_msg_id` int(255) NOT NULL," +
                    "  `msg` varchar(1000) NOT NULL" +
                    ")" +
                    "CREATE TABLE `bairro`(" +
                    "  `chat_bairro` int NOT NULL," +
                    "  `user_id` int NOT NULL," +
                    "  `id` int NOT NULL," +
                    " `name` varchar(100) NOT NULL" +
                    ");"+"ALTER TABLE `bairro`" +
                    "  ADD PRIMARY KEY (`user_id`);"+
                    "CREATE TABLE `chatSaoJose`(" +
                    "  `id_bairro_chat` int NOT NULL," +
                    "  `id_usu` int not null," +
                    "  `msg_id` int not null," +
                    "  `msg_txt` varchar(255) not null" +
                    ");" +
                    "ALTER TABLE `ChatSaoJose`" +
                    " ADD PRIMARY KEY (`msg_id`);" +
                    "insert into `bairro`(chat_bairro,user_id,id,name)\n" +
                    "values(1,1,1,'São José');");

        }catch (Exception e){
            abrirBanco();
        }


    }
}
