package com.example.ajudacap;

public class Chat {
}
